// Adicione no início do arquivo servicos.js
document.getElementById('servicos').classList.add('initially-hidden');

// Atualize a função confirmarNumeroCartao() no arquivo menu.js
async function confirmarNumeroCartao() {
    // Obtenha o número do cartão do input
    const numeroCartao = document.getElementById('numeroCartao').value;

    // Verifique se o número do cartão é válido (adapte conforme necessário)
    if (!numeroCartao || isNaN(numeroCartao)) {
        alert('Por favor, insira um número de cartão válido.');
        return;
    } else {
        alert('Cartão confirmado com sucesso');
    }

    // Oculte a seção de serviços
    document.getElementById('servicos').classList.remove('initially-hidden');

    // Faça uma requisição ao servidor para validar o número do cartão
    const isValid = await validarCartaoNoBanco(numeroCartao);

    if (isValid) {
        // Atualize a variável global com o número do cartão atual
        numeroDoCartaoAtual = numeroCartao;
        console.log('Número do Cartão Confirmado:', numeroDoCartaoAtual);

        // Exiba os botões de check com base nos produtos associados ao cartão
        mostrarBotoesCheck();
        mostrarBotoesRecompensa();
    } else {
        alert('Número do cartão inválido. Por favor, insira um número válido.');
    }
}

// Função para adicionar um botão de check à lista
function adicionaBotaoCheck(nomeProduto) {
    var checkButtonsContainer = document.getElementById('check-buttons-container');
    var checkButton = document.createElement('button');
    
    // Defina o texto do botão como o nome do produto
    checkButton.textContent = nomeProduto;

    // Adicione um ouvinte de evento ao botão
    checkButton.addEventListener('click', function() {
        // Por exemplo, você pode marcar o produto como selecionado
        console.log('Botão de check clicado para o produto:', nomeProduto);
    });

    // Adicione o botão à lista
    checkButtonsContainer.appendChild(checkButton);
}

// Atualize a função mostrarBotoesCheck no arquivo servico.js
async function mostrarBotoesCheck() {
    try {
        // Faça uma requisição ao servidor para obter os produtos associados ao cartão
        const response = await fetch('/buscarProdutosDoCartao', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ numeroCartao: numeroDoCartaoAtual }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao buscar produtos do cartão: ${response.status}`);
        }

        const data = await response.json();

        if (data.success && data.produtos) {
            // Limpe os botões existentes antes de adicionar os novos
            limparBotoesCheck();

            // Crie um botão de check para cada produto associado ao cartão
            data.produtos.forEach(produto => {
                const botaoCheck = criarBotaoCheck(produto.id, produto.nome_servico);
                document.getElementById('product-list').appendChild(botaoCheck);
            });

            // Adicione no final da função mostrarBotoesCheck
            const botaoDesmarcar = document.createElement('button');
            botaoDesmarcar.innerText = 'Confirmar serviços';
            botaoDesmarcar.addEventListener('click', desmarcarProduto);
            document.getElementById('product-list').appendChild(botaoDesmarcar);
        } else {
            throw new Error('Produtos do cartão não encontrados.');
        }
    } catch (error) {
        console.error(error);
        alert('Erro ao buscar produtos do cartão.');
    }
}

// Função para desativar os botões dos produtos já utilizados
function desativarBotoesProdutosUtilizados(produtosUtilizados) {
    // Desative os botões dos produtos já utilizados
    produtosUtilizados.forEach(produtoUtilizado => {
        const botaoCheck = document.querySelector(`.product-checkbox[data-id="${produtoUtilizado.id}"]`);
        if (botaoCheck) {
            botaoCheck.disabled = true;
        }
    });
}

// Função para limpar os botões de check existentes
function limparBotoesCheck() {
    const productList = document.getElementById('product-list');
    productList.innerHTML = ''; // Limpe todos os itens da lista
}

// Função para criar um botão de check para um produto específico
function criarBotaoCheck(idProduto, nomeProduto) {
    const botaoCheck = document.createElement('li');
    botaoCheck.innerHTML = `
        <label>
            <input type="checkbox" class="product-checkbox" data-id="${idProduto}">${idProduto} ${nomeProduto} 
        </label>
    `;
    return botaoCheck;
}


// Atualize a função desmarcarProduto no arquivo servico.js
async function desmarcarProduto() {
    try {
        console.log('Desmarcando produtos...'); // Adicione este log

        // Obtenha todos os checkboxes marcados
        const checkboxes = document.querySelectorAll('.product-checkbox:checked');

        if (checkboxes.length === 0) {
            alert('Selecione pelo menos um produto para confirmar.');
            return;
        }

        // Obtenha os IDs dos produtos marcados e converta para números inteiros
        const produtosSelecionados = Array.from(checkboxes).map(checkbox => parseInt(checkbox.dataset.id, 10));

        // Faça uma solicitação ao servidor para confirmar os serviços (definir flag para 0)
        const response = await fetch('/confirmarServicos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                produtos: produtosSelecionados,
            }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao confirmar serviços: ${response.status}`);
        }

        // Atualize os botões de check após confirmar os serviços
        mostrarBotoesCheck();
    } catch (error) {
        console.error(error);
        alert('Erro ao confirmar serviços.');
    }
}


// Adicione no arquivo servicos.js
document.addEventListener('DOMContentLoaded', () => {
    // Adicione um ouvinte de evento ao botão de desmarcar
    const botaoDesmarcar = document.getElementById('botaoDesmarcar');
    if (botaoDesmarcar) {
        botaoDesmarcar.addEventListener('click', desmarcarProduto);
    }
});



// Função para buscar os produtos associados ao número do cartão no banco de dados
async function buscarProdutosDoCartaoNoBanco(numeroCartao) {
    try {
        const response = await fetch('/buscarProdutosDoCartao', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ numeroCartao }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao buscar produtos do cartão: ${response.status}`);
        }

        const data = await response.json();

        // 'data.produtos' deve conter a lista de produtos associados ao número do cartão
        console.log('Produtos associados ao número do cartão:', data.produtos);
    } catch (error) {
        console.error(error);
    }
}

// Função para buscar o nome da recompensa no servidor com base no id_servico
async function buscarNomeRecompensa(idServico) {
    try {
        const response = await fetch('/buscarNomeRecompensa', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ idServico }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao buscar nome da recompensa: ${response.status}`);
        }

        const data = await response.json();

        return data.nomeRecompensa;
    } catch (error) {
        console.error(error);
        throw new Error('Erro ao buscar nome da recompensa.');
    }
}

// Atualize a função mostrarBotoesRecompensa no arquivo servicos.js
async function mostrarBotoesRecompensa() {
    try {
        // Faça uma requisição ao servidor para obter as recompensas associadas ao cliente
        const response = await fetch('/buscarRecompensasDoCliente', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ clienteCartao: numeroDoCartaoAtual }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao buscar recompensas do cliente: ${response.status}`);
        }

        const data = await response.json();

        // 'data.recompensas' deve conter a lista de recompensas associadas ao cliente
        console.log('Recompensas associadas ao cliente:', data.recompensas);

        // Limpe os botões existentes antes de adicionar os novos
        limparBotoesRecompensa();

        // Crie um botão de check para cada recompensa associada ao cliente
        data.recompensas.forEach(recompensa => {
            const botaoRecompensa = criarBotaoRecompensa(recompensa.id, recompensa.nome_servico);
            document.getElementById('recompensa-list').appendChild(botaoRecompensa);
        });

        // Adicione no final da função mostrarBotoesRecompensa
        const botaoConfirmarRecompensa = document.createElement('button');
        botaoConfirmarRecompensa.innerText = 'Confirmar recompensas';
        botaoConfirmarRecompensa.addEventListener('click', confirmarRecompensa);
        document.getElementById('recompensa-list').appendChild(botaoConfirmarRecompensa);

        console.log('Botões de recompensa adicionados com sucesso.');
    } catch (error) {
        console.error(error);
        alert('Erro ao buscar recompensas do cliente.');
    }
}

// Função para confirmar as recompensas selecionadas
async function confirmarRecompensa() {
    try {
        console.log('Confirmando recompensas...');

        // Obtenha todas as checkboxes marcadas
        const checkboxes = document.querySelectorAll('.recompensa-checkbox:checked');

        if (checkboxes.length === 0) {
            alert('Selecione pelo menos uma recompensa para confirmar.');
            return;
        }

        // Obtenha os IDs das recompensas marcadas e converta para números inteiros
        const recompensasSelecionadas = Array.from(checkboxes).map(checkbox => parseInt(checkbox.dataset.id, 10));

        // Faça uma solicitação ao servidor para confirmar as recompensas
        const response = await fetch('/confirmarRecompensas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                recompensas: recompensasSelecionadas,
            }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao confirmar recompensas: ${response.status}`);
        }

        // Atualize os botões de check após confirmar as recompensas
        mostrarBotoesRecompensa();
    } catch (error) {
        console.error(error);
        alert('Erro ao confirmar recompensas.');
    }
}


// Função para desativar os botões das recompensas já utilizadas
function desativarBotoesRecompensasUtilizadas(recompensasUtilizadas) {
    // Desative os botões das recompensas já utilizadas
    recompensasUtilizadas.forEach(recompensaUtilizada => {
        const botaoCheck = document.querySelector(`.recompensa-checkbox[data-id="${recompensaUtilizada.id}"]`);
        if (botaoCheck) {
            botaoCheck.disabled = true;
        }
    });
}

// Função para limpar os botões de recompensa existentes
function limparBotoesRecompensa() {
    const recompensaList = document.getElementById('recompensa-list');
    recompensaList.innerHTML = ''; // Limpe todos os itens da lista
}

// Atualize a função criarBotaoRecompensa
function criarBotaoRecompensa(idRecompensa, nomeServico) {
    const botaoRecompensa = document.createElement('li');
    botaoRecompensa.innerHTML = `
        <label>
            <input type="checkbox" class="recompensa-checkbox" data-id="${idRecompensa}">
            ${idRecompensa} ${nomeServico}
        </label>
    `;
    return botaoRecompensa;
}


// Atualize a função desmarcarRecompensa no arquivo recompensas.js
async function desmarcarRecompensa() {
    try {
        console.log('Desmarcando recompensas...'); // Adicione este log

        // Obtenha todas as checkboxes marcadas
        const checkboxes = document.querySelectorAll('.recompensa-checkbox:checked');

        if (checkboxes.length === 0) {
            alert('Selecione pelo menos uma recompensa para confirmar.');
            return;
        }

        // Obtenha os IDs das recompensas marcadas e converta para números inteiros
        const recompensasSelecionadas = Array.from(checkboxes).map(checkbox => parseInt(checkbox.dataset.id, 10));

        // Faça uma solicitação ao servidor para confirmar as recompensas (definir flag para 0)
        const response = await fetch('/confirmarRecompensas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                recompensas: recompensasSelecionadas,
            }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao confirmar recompensas: ${response.status}`);
        }

        // Atualize os botões de check após confirmar as recompensas
        mostrarBotoesRecompensa();
    } catch (error) {
        console.error(error);
        alert('Erro ao confirmar recompensas.');
    }
}

// Adicione no arquivo recompensas.js
document.addEventListener('DOMContentLoaded', () => {
    // Adicione um ouvinte de evento ao botão de desmarcar recompensa
    const botaoDesmarcarRecompensa = document.getElementById('botaoDesmarcarRecompensa');
    if (botaoDesmarcarRecompensa) {
        botaoDesmarcarRecompensa.addEventListener('click', desmarcarRecompensa);
    }
});

// Função para buscar as recompensas associadas ao cliente_cartao no banco de dados
async function buscarRecompensasDoClienteNoBanco(clienteCartao) {
    try {
        console.log('Dados do servidor para recompensas:', data);
        const response = await fetch('/buscarRecompensasDoCliente', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ clienteCartao }),
        });

        if (!response.ok) {
            throw new Error(`Erro ao buscar recompensas do cliente: ${response.status}`);
        }

        const data = await response.json();

        // 'data.recompensas' deve conter a lista de recompensas associadas ao cliente
        console.log('Recompensas associadas ao cliente:', data.recompensas);
    } catch (error) {
        console.error(error);
    }
}
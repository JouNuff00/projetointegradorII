const express = require('express');
const bodyParser = require('body-parser');
const conexao = require('./conexao');
const path = require('path');

const app = express();
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'public')));

app.get("/", (req, res) => {
    const filePath = path.join(__dirname, "public", "index.html");
    res.sendFile(filePath);
});

async function gerarNumeroCartaoAleatorio() {
    let numeroCartao;
    let cartaoExistente;

    do {
        numeroCartao = Math.floor(Math.random() * 1000); // Gera um número aleatório entre 0 e 1000
        [cartaoExistente, _] = await conexao.execute('SELECT * FROM Cartao WHERE id_cartao = ?', [numeroCartao]);
    } while (cartaoExistente.length > 0);

    return numeroCartao;
}

app.post('/gerarCartao', async (req, res) => {//aqui é metodo post que vai criar na rota gerarCartao um cartao aleatorio
    try {
        const numeroCartao = await gerarNumeroCartaoAleatorio();//aqui a funçaõ esta sendo chamada
        await conexao.execute('INSERT INTO Cartao (id_cartao) VALUES (?)', [numeroCartao]);
        console.log(numeroCartao);
        res.status(200).json({ numeroCartao: numeroCartao });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Erro interno do servidor ao gerar o cartão.' });
    }
});

app.post('/produtos/comprar', async (req, res) => {
    console.log(req.body)
    return res.render('Serviço');
})


const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
    console.log(`Servidor está rodando na porta ${PORT}`);
});
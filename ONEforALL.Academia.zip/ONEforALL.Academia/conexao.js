const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: "us-cdbr-east-06.cleardb.net",
    user: "b6deb5b048057d",
    password: "ed8f1b36",
    database: "heroku_59b3699c56a9a1f",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = pool;